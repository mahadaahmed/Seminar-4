package se.kh.iv1350.pointofsale.integration.observer;

/**
 * This is the observer interface according to the observer pattern
 */
public interface Observer {

    public void update (int totalRevenue);

}
